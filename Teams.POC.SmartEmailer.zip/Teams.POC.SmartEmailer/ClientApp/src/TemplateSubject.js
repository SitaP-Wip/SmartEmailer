﻿import React, { Component } from 'react';
import { Flex, Text } from '@fluentui/react-northstar'

function TemplateSubject(props) {
    return (
        <Text content={props.value} size="small" truncated weight="semilight" />
    );
}
export default TemplateSubject;

//<Flex column gap="gap.smallest">
//    <Text content={props.value} size="small" truncated weight="semilight" />
//    <Text content={"Recipient1; Recipient2; Recipient3; Recipient4; Recipient5"} size="small" truncated weight="semilight" />
//</Flex>