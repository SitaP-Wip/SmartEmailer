﻿import React, { Component } from 'react';
import { Tree, treeAsListBehavior, Accordion, ListItem, Button, ButtonGroup, Flex, Dropdown, Grid, Card, Box, Segment, Label, FlexItem, Divider, EditIcon, ParticipantAddIcon, Input, Text, Attachment, CalendarIcon, SyncIcon, ContentIcon, Checkbox, Datepicker, WordColorIcon, ExcelColorIcon, PowerPointColorIcon, ComposeIcon, ChatMessage, UserBlurIcon, Header } from '@fluentui/react-northstar'
import { TriangleDownIcon, TriangleEndIcon, ThumbtackIcon, ThumbtackSlashIcon, MoreIcon, SearchIcon } from '@fluentui/react-icons-northstar'
import List from "./List";
import TemplateItem from "./TemplateItem";
import App from "./App";
import FilterPanel from './FilterPanel';
import TemplateHeader from './TemplateHeader';
import LastAccessed from './LastAccessed';
import TemplateSubject from './TemplateSubject';
import MailImportance from './MailImportance';
function SavedTemplatesSplitScreen0(props) {
    //const [state, setState] = React.useState({ selectedIndex: 0 })
    //const getTemplateItem = (template, index) => {
    //    return <ListItem key={index} header={template.header} content={template.content} contentMedia={template.contentMedia}
    //        headerMedia={template.headerMedia} endMedia={template.endMedia} pinned={template.pinned} frequentlyUsed={template.frequentlyUsed} selectable
    //        selectedIndex={state.selectedIndex}
    //        onSelectedIndexChange={(e, newProps) => {
    //            //alert(
    //            //    `Showing preview for "${newProps.selectedIndex}"`,
    //            //)
    //            setState({
    //                selectedIndex: newProps.selectedIndex,
    //            })
    //            props.changeTemplatePreviewData(newProps.selectedIndex)
    //        }}
    //        truncateHeader={true}
    //        truncateContent={true} />
    //}
    const getTemplateItem = (template, index) => {
        return <TemplateItem template={template} changeTemplatePreviewData={props.changeTemplatePreviewData} selected={props.currentTemplate.selectedTemplate == template.header}/>
    }
    const pinnedTemplates = props.templates.filter(template => template.pinned == true).map(getTemplateItem)
    const frequentlyUsedTemplates = props.templates.filter(template => template.frequentlyUsed == true).map(getTemplateItem)
    const myTemplates = props.templates.filter(template => template.frequentlyUsed == false && template.pinned == false).map(getTemplateItem)
    

    const items = [
        {
            id: 'pinned-templates',
            title: 'Pinned Templates',
            content: <List templates={props.templates.filter(template => template.pinned == true)} selectedTemplateIndex={0} changeTemplatePreviewData={props.changeTemplatePreviewData} />,
        },
        {
            id: 'frequently-used',
            title: 'Frequently Used',
            content: <List templates={props.templates.filter(template => template.pinned == true)} selectedTemplateIndex={0} changeTemplatePreviewData={props.changeTemplatePreviewData} />
        },
        {
            id: 'my-templates',
            title: 'My Templates',
            content: <List templates={props.templates.filter(template => template.pinned == true)} selectedTemplateIndex={0} changeTemplatePreviewData={props.changeTemplatePreviewData} />
        },
    ]
    const panels = [
        {
            title: 'Pinned Templates',
            content: pinnedTemplates,
        },
        {
            title: 'Frequently Used',
            content: frequentlyUsedTemplates,
        },
        {
            title: 'My Templates',
            content: myTemplates,
        }
    ]
   
    return (
        <div >
            <FilterPanel />
            {/*<Tree aria-label="Custom title" items={items} accessibility={treeAsListBehavior} styles={{ marginTop: '2.7rem' }} />*/}
            {<Accordion defaultActiveIndex={[0, 1, 2]} panels={panels} styles={{ marginTop: '2.7rem', width: '19rem' }} />}
        </div>
    );
}
export default SavedTemplatesSplitScreen0;

//BACKUP 1
//const panels = [
//    {
//        title: 'Pinned Templates',
//        content: pinnedTemplates,
//    },
//    {
//        title: 'Frequently Used',
//        content: (
//            <List templates={props.templates.filter(template => template.frequentlyUsed == true)} changeTemplatePreviewData={props.changeTemplatePreviewData} />
//        ),
//    },
//    {
//        title: 'My Templates',
//        content: (
//            <List templates={props.templates.filter(template => template.frequentlyUsed == false && template.pinned == false)} changeTemplatePreviewData={(id) => props.changeTemplatePreviewData(id)} />
//        ),
//    }
//]
//BACKUP 0
//const pinActions = (
//    <ButtonGroup
//        buttons={[
//            {
//                icon: <ThumbtackSlashIcon />,
//                iconOnly: true,
//                text: true,
//                title: 'unpin',
//                key: 'unpin',
//            },
//            {
//                icon: <MoreIcon />,
//                iconOnly: true,
//                text: true,
//                title: 'more',
//                key: 'more',
//            },
//        ]}
//    />
//);
//const pinSelectedTemplate = (item) => {
//    alert(item)
//}
//const templateClick = (props) => {
//    alert(
//        `preview for "${props}"`,
//    )
//    setState({
//        selectedIndex: -1,
//    })
//}
//const actions = (
//    <ButtonGroup
//        buttons={[
//            {
//                icon: <ThumbtackIcon />,
//                iconOnly: true,
//                text: true,
//                title: 'pin',
//                key: 'pin',
//                onClick: pinSelectedTemplate
//            },
//            {
//                icon: <MoreIcon />,
//                iconOnly: true,
//                text: true,
//                title: 'more',
//                key: 'more',
//            },
//        ]}
//    />
//);
//const myTemplates = [
//    {
//        key: 'irving1',
//        header: <TemplateHeader value={"Template Name 1"} />,
//        headerMedia: <LastAccessed value={"09:20 AM"} />,
//        content: <TemplateSubject value={'Subject 1 - Test email 1 || truncate check smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
//        contentMedia: <MailImportance value={'high'} />,
//        endMedia: pinActions,
//        pinned: true,
//        frequentlyUsed: false,
//        onClick: () => { templateClick() }
//    },
//    {
//        key: 'irving2',
//        header: <TemplateHeader value={"Template Name 2"} />,
//        headerMedia: <LastAccessed value={"11:10 PM"} />,
//        content: <TemplateSubject value={'Subject 2 - Test email 2 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
//        contentMedia: '',
//        endMedia: pinActions,
//        pinned: true,
//        frequentlyUsed: false,
//    },
//    {
//        key: 'irving3',
//        header: <TemplateHeader value={"Template Name 3"} />,
//        headerMedia: <LastAccessed value={"12:00 AM"} />,
//        content: <TemplateSubject value={'Subject 3 - Test email 3 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
//        contentMedia: <MailImportance value={'high'} />,
//        endMedia: pinActions,
//        pinned: true,
//        frequentlyUsed: false,
//    },
//    {
//        key: 'irving4',
//        header: <TemplateHeader value={"Template Name 4"} />,
//        headerMedia: <LastAccessed value={"4/12"} />,
//        content: <TemplateSubject value={'Subject 1 - Test email 1 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
//        contentMedia: <MailImportance value={'high'} />,
//        endMedia: actions,
//        pinned: false,
//        frequentlyUsed: true,
//    },
//    {
//        key: 'irving5',
//        header: <TemplateHeader value={"Template Name 5 truncate check lengthy text"} />,
//        headerMedia: <LastAccessed value={"2/12"} />,
//        content: <TemplateSubject value={'Subject 1 - Test email 1 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
//        contentMedia: '',
//        endMedia: actions,
//        pinned: false,
//        frequentlyUsed: false,
//    },
//    {
//        key: 'irving6',
//        header: <TemplateHeader value={"Template Name 6"} />,
//        headerMedia: <LastAccessed value={"30/11"} />,
//        content: <TemplateSubject value={'Subject 1 - Test email 1 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
//        contentMedia: '',
//        endMedia: actions,
//        pinned: false,
//        frequentlyUsed: true,
//    },
//    {
//        key: 'irving7',
//        header: <TemplateHeader value={"Template Name 7"} />,
//        headerMedia: <LastAccessed value={"24/11"} />,
//        content: <TemplateSubject value={'Subject 1 - Test email 1 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
//        contentMedia: <MailImportance value={'high'} />,
//        endMedia: actions,
//        pinned: false,
//        frequentlyUsed: false,
//    }

//]