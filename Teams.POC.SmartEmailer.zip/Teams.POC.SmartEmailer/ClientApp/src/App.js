import React, { Component, useState, useEffect } from 'react';
import { Provider, teamsTheme, Accordion, Button, ButtonGroup, Flex, Menu, menuAsToolbarBehavior, tabListBehavior, Dropdown, Grid, Box, Segment, Text, Label, FlexItem, Divider, EditIcon, ParticipantAddIcon, Input, Attachment, CalendarIcon, SyncIcon, ContentIcon, Checkbox, Datepicker, WordColorIcon, ExcelColorIcon, PowerPointColorIcon, ComposeIcon, ChatMessage, UserBlurIcon } from '@fluentui/react-northstar'
import { ThumbtackIcon, ThumbtackSlashIcon, MoreIcon, TrashCanIcon, EmailIcon } from '@fluentui/react-icons-northstar'
import logo from './logo.svg';
import './App.css';
import { useTeams, checkInTeams } from "msteams-react-base-component";
import * as microsoftTeams from "@microsoft/teams-js";

import AppRoute from './SERouter'
import ComposeEmail from './ComposeEmail'
import SavedTemplate from './SavedTemplate';

function App(props) {
    const [{ inTeams, theme }] = useTeams({ initialTheme: 'default' });
    const [ state, setState ] = useState({ theme: '' });
    const [isTeams, setIsTeams] = useState(false);
    const [tab, setTab] = useState('Compose Email');
    //const [tab, setTab] = useState('Saved Templates');
    useEffect(() => {
        if (inTeams === true) {
            setIsTeams(true);
        } else {
            if (inTeams !== undefined) {
                setIsTeams(false);
            }
        }
    }, [inTeams]);

    const items = [
        {
            key: 'composeEmail',
            content: <Text content="Compose Email" size="regular" weight="regular" />,
        },
        {
            key: 'savedTemplates',
            content: <Text content="Saved Templates" size="regular" weight="regular" />
        },
        {
            key: 'sentItems',
            content: <Text content="Sent Items" size="regular" weight="regular" />,
        },
    ]
    useEffect(() => {
        microsoftTeams.initialize();
        microsoftTeams.getContext((context) => {
            let built_in_theme = context.theme || "";
            setState({ theme: built_in_theme })
        });

        microsoftTeams.registerOnThemeChangeHandler((theme) => {
            setState({
                theme: theme,
            }, () => {
                this.forceUpdate();
            });
        });
    }, [])
    
    const setThemeComponent = () => {
        if (!isTeams) {
            return (
                <Provider theme={theme}>
                    {!isTeams ? <>
                        <Flex row gap="gap.small" fluid styles={{ backgroundColor: 'brand', paddingTop: '0.5rem', paddingBottom: '0', paddingLeft: '1rem' }}>
                            <EmailIcon size="larger" />
                            <Text content="Smart Email" size="large" weight="bold" />
                            <Menu
                                defaultActiveIndex={0}
                                items={items}
                                underlined
                                primary
                                accessibility={tabListBehavior}
                                aria-label="Today's events"
                                styles={{ paddingLeft: '1rem', border: 'none' }}
                                fluid
                            />
                        </Flex>
                        <Divider size={1} fitted />
                    </>
                        : null}
                    {tab == 'Compose Email' ? <ComposeEmail isEditable={true} /> : <SavedTemplate />}
                </Provider>
                );
        }
        if (state.theme === "dark") {
            return (
                <Provider theme={teamsTheme.teamsDark}>
                    <div className="darkContainer">
                        {getAppDom()}
                    </div>
                </Provider>
            );
        }
        else if (state.theme === "contrast") {
            return (
                <Provider theme={teamsTheme.teamsHighContrast}>
                    <div className="highContrastContainer">
                        {getAppDom()}
                    </div>
                </Provider>
            );
        }
        else {
            return (
                <Provider theme={theme}>
                    <div className="default-container">
                        {getAppDom()}
                    </div>
                </Provider>
            );
        }
    }
    const getAppDom = () => {
        return (
            <div className="app-container">
                <AppRoute />
            </div>
        );
    }

    return (
        <div>
            {setThemeComponent()}
        </div>
        
        
        );
}

export default App;


//import React, { Component } from 'react';
//import logo from './logo.svg';
//import './App.css';
//import { Button, Flex, Dropdown, DropdownSelectedItem, Grid, Segment, Label, FlexItem, Divider, EditIcon, ParticipantAddIcon, Input, Attachment, CalendarIcon, SyncIcon, ContentIcon, Checkbox, Datepicker, WordColorIcon, ExcelColorIcon, PowerPointColorIcon, ComposeIcon, ChatMessage, UserBlurIcon } from '@fluentui/react-northstar'
//import Editor from "./ReactQuillEditor";
//import MailSubject from "./MailSubject";
//import { CloseIcon, ChatIcon } from '@fluentui/react-icons-northstar'
//import { useState } from 'react'
////import { useBooleanKnob } from '@fluentui/docs-components'

//function App(props) {
//    const [isPreview, setIsPreview] = React.useState(!props.isEditable);
//    const [selectedPerson, setSelectedPerson] = React.useState(-1);
//    const [mails, setMails] = React.useState([]);
//    const inputItems = [
//        {
//            header: 'Bruce Wayne',
//            image: 'public/images/avatar/small/matt.jpg',
//            content: 'Software Engineer',
//            firstName: 'Bruce'
//        },
//        {
//            header: 'Natasha Romanoff',
//            image: 'public/images/avatar/small/jenny.jpg',
//            content: 'UX Designer 2',
//            firstName: 'Natasha'

//        },
//        {
//            header: 'Steven Strange',
//            image: 'public/images/avatar/small/joe.jpg',
//            content: 'Principal Software Engineering Manager',
//            firstName: 'Natasha'
//        },
//        {
//            header: 'Alfred Pennyworth',
//            image: 'public/images/avatar/small/justen.jpg',
//            content: 'Technology Consultant',
//            firstName: 'Natasha'
//        },
//        {
//            header: `Scarlett O'Hara`,
//            image: 'public/images/avatar/small/laura.jpg',
//            content: 'Software Engineer 2',
//            firstName: 'Natasha'
//        },
//        {
//            header: 'Imperator Furiosa',
//            image: 'public/images/avatar/small/veronika.jpg',
//            content: 'Boss',
//            firstName: 'Natasha'
//        },
//        {
//            header: 'Bruce Banner',
//            image: 'public/images/avatar/small/chris.jpg',
//            content: 'Senior Computer Scientist',
//            firstName: 'Natasha'
//        },
//        {
//            header: 'Peter Parker',
//            image: 'public/images/avatar/small/daniel.jpg',
//            content: 'Partner Software Engineer',
//            firstName: 'Natasha'
//        },
//        {
//            header: 'Selina Kyle',
//            image: 'public/images/avatar/small/ade.jpg',
//            content: 'Graphic Designer',
//            firstName: 'Natasha'
//        },
//    ]

//    const persons = [
//        'Bruce Wayne',
//        'Natasha Romanoff',
//        'Steven Strange',
//        'Alfred Pennyworth',
//        `Scarlett O'Hara`,
//        'Imperator Furiosa',
//        'Bruce Banner',
//        'Peter Parker',
//        'Selina Kyle',
//        'Dheeraj Kasivi',
//        'Vandana Srivatsava',
//        'Kishore Kumar AVN',
//        'Lalitha Aadukuri',
//        'Amit Mann',
//        'Sita Prasad'
//    ]

//    const timeZones = [
//        '+5:00',
//        '+5:30',
//        '+5:45',
//        '-5:00',
//        '-4:00',
//        '-4:30',
//        '-4:45'
//    ]
//    //const getA11ySelectionMessage = {
//    //    onAdd: item => alert(`${item.header} has been selected.`),
//    //    onRemove: item => alert(`${item.header} has been removed.`)
//    //}
//    const [messagePersonalize, setmessagePersonalize] = React.useState({ value: null });
//    const peopleClick = e => {
//        console.log("clicked");
//    };
//    const getA11ySelectionMessage = {
//        onAdd: item => addMail(item),
//        onRemove: item => removeMail(item),
//        onHighlightedIndexChange: item => alert(item.header)
//    }
//    const addMail = (item) => {
//        setSelectedPerson(mails.length)
//        setMails([...mails, {
//            id: mails.length,
//            person: item.header,
//            subject: 'personalize subject || ' + item.header,
//            body: 'Hi ' + item.header,
//            firstName: 'sample'
//            //isSelected: true
//        }])
//    }
//    const removeMail = (item) => {
//        alert(item.header);
//    }
//    const updateMail = (item) => {
//        alert('update')
//        setMails(
//            mails.map(mail =>
//                mail.id === item.id
//                    ? { ...mail, isSelected: true }
//                    : mail
//            ))
//    }
//    const _onChange = () => {
//        setIsPreview(current => !current);
//    }
//    const getCurrentSubject = () => {
//        if (mails.length > 0)
//            return mails.filter(mail => mail.id == selectedPerson)[0].subject
//        else
//            return 'default subject'
//    }
//    const getCurrentMailBody = () => {
//        if (mails.length > 0)
//            return mails.filter(mail => mail.id == selectedPerson)[0].body
//        else
//            return 'default body'
//    }

    
//    const Results = () => (
//        <div>
//            <Flex gap="gap.small">
//                <FlexItem push>
//                    <Button content="Save" primary />
//                </FlexItem>
//                <Button content="Cancel" />
//            </Flex>
//            <Divider />
//        </div>
//    )
//    return (
//        <div>
//            {isPreview ? null : <Results />}
//            <Flex grow>
//                <Flex.Item push>
//                    <Checkbox label="Preview Mail" toggle onChange={_onChange} />
//                </Flex.Item>
//            </Flex>
//            <Divider />

//            <Grid columns="0.1fr 4fr" grow>
//                <Segment>
//                    <UserBlurIcon size="large" outline />
//                </Segment>
//                <Segment>
//                    {isPreview ? <Input placeholder="On behalf of" fluid disabled/> : <Input placeholder="On behalf of" fluid />}
//                </Segment>
//                <Segment>
//                    <ParticipantAddIcon size="large" outline />
//                </Segment>
//                <Segment>
//                    <Flex gap="gap.smaller">
//                        <FlexItem grow>
//                            {isPreview ? <Dropdown
//                                multiple
//                                search
//                                fluid
//                                items={inputItems}
//                                placeholder="Add recipients"
//                                getA11ySelectionMessage={getA11ySelectionMessage}
//                                noResultsMessage="We couldn't find any matches."
//                                onClick={peopleClick}
//                                disabled /> : <Dropdown
//                                    multiple
//                                    search
//                                    fluid
//                                    items={inputItems}
//                                    placeholder="Add recipients"
//                                    getA11ySelectionMessage={getA11ySelectionMessage}
//                                    noResultsMessage="We couldn't find any matches."
//                                    onClick={peopleClick}
//                                     /> }
//                        </FlexItem>

//                        {!isPreview ? <Button content="Dynamic Audience" loader="Opening Dynamic Audience" secondary /> :
//                            <Button content="Dynamic Audience" loader="Opening Dynamic Audience" secondary hidden />}
//                    </Flex>

//                </Segment>
//                <Segment>
//                    <EditIcon size="large" outline />
//                </Segment>
//                <Segment>
//                    <Flex gap="gap.smaller">
//                        <FlexItem grow>
//                            {isPreview ? <MailSubject mailSubject={getCurrentSubject()} /> :
//                                <MailSubject mailSubject={getCurrentSubject()} disabled />}
//                        </FlexItem>
//                        <FlexItem push>
//                            <Dropdown items={['High Importance', 'Normal']} fluid />
//                        </FlexItem>
//                        {!isPreview ? <Button content="Personalize" loader="Opening Personalize" size="large" primary className="Personalize" />:
//                            <Button content="Personalize" loader="Opening Personalize" size="large" primary className="Personalize" hidden/> }
//                    </Flex>
//                </Segment>
//                <Segment>
//                    <ChatIcon size="large" outline />
//                </Segment>
//                <Segment>
//                    <Editor messageBody={getCurrentMailBody()} isEditable={!isPreview} />
//                </Segment>
//                <Segment>

//                </Segment>
//                <Segment>
//                    <Attachment icon={<WordColorIcon />} header="MeetingNotes.docx" />
//                    <Attachment icon={<ExcelColorIcon />} header="Budget.xlsx" />
//                    <Attachment icon={<PowerPointColorIcon />} header="Presentation.pptx" />
//                    <Attachment
//                        header="Photo.jpg"
//                        actionable
//                        action={{
//                            icon: <CloseIcon />,
//                            title: 'Close',
//                        }}
//                        progress={33}
//                    />
//                </Segment>
//            </Grid>
//        </div>
//    );
//}

//export default App;
