﻿import React, { Component } from 'react';
import { Text } from '@fluentui/react-northstar'

function TemplateHeader(props) {
    return (
        <Text content={props.value} size="medium" truncated weight="regular" />
    );
}
export default TemplateHeader;
