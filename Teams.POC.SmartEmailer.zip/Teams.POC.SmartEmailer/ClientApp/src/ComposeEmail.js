﻿import React, { Component } from 'react';
import * as microsoftTeams from "@microsoft/teams-js";
import logo from './logo.svg';
import './App.css';
import { Dialog, Button, SplitButton, Flex, Dropdown, DropdownSelectedItem, Grid, Segment, Label, FlexItem, Divider, EditIcon, ParticipantAddIcon, Input, Attachment, CalendarIcon, SyncIcon, ContentIcon, Checkbox, Datepicker, WordColorIcon, ExcelColorIcon, PowerPointColorIcon, ComposeIcon, ChatMessage, UserBlurIcon } from '@fluentui/react-northstar'
import TaskModal from "./TaskModal";
import Personalize from "./Personalize";
import Editor from "./ReactQuillEditor";
import MailSubject from "./MailSubject";
import { CloseIcon, ChatIcon } from '@fluentui/react-icons-northstar'
import { useState } from 'react'
import { useTeams, checkInTeams } from "msteams-react-base-component";

//import { useBooleanKnob } from '@fluentui/docs-components'

function ComposeEmail(props) {

    const getBaseUrl = () => {
        return window.location.origin;
    }
    const [open, setOpen] = React.useState(false);
    const [inTeams, SetInTeams] = React.useState(checkInTeams);
    const [isPreview, setIsPreview] = React.useState(!props.isEditable);
    const [selectedPerson, setSelectedPerson] = React.useState(-1);
    const [mails, setMails] = React.useState([]);
    let isOpenTaskModuleAllowed = true;
     const onOpenTaskModule = () => {
         if (isOpenTaskModuleAllowed) {
            setOpen(true)
            isOpenTaskModuleAllowed = false;
            const url = getBaseUrl() + "/Personalize";
            //"id": "4b8d2936-4e5f-4563-83ca-4bdad686c799",
            //"webApplicationInfo": {
            //    "id": "de0a06e9-e230-41f5-9e13-08279fee2eb8",
            //        "resource": "api://kishoregrouplookup.azurefd.net/de0a06e9-e230-41f5-9e13-08279fee2eb8"
            //}
            //console.log(getBaseUrl() + "/Personalize")
            //const url = "https://teams.microsoft.com/l/task/de0a06e9-e230-41f5-9e13-08279fee2eb8?url='https://localhost:44354/Personalize'&height='400'&width='700'&title='Personalize'";
            //if (!checkInTeams) {
            //    alert('opening...')
            //    url = "https://teams.microsoft.com/l/task/APP_ID?url='https://teams.microsoft.com/_#/apps/821861ba-d38f-4a21-b9f9-de3dd33e3e09/sections/ComposeMail/Personalize'&height='400'&width='700'&title='Personalize'";
            //}
            const taskInfo = {
                url: url,
                title: 'Personalize',
                height: 400,
                width: 700,
                fallbackUrl: url,
            }
            //console.log(taskInfo.url)
            //const url = "https://teams.microsoft.com/l/task/<APP_ID>**?url=<TaskInfo.url>**&height=<TaskInfo.height>&width=<TaskInfo.width>&title=<TaskInfo.title>"
            const submitHandler = (err, result) => {
                isOpenTaskModuleAllowed = true;
                if (result != null) {
                    if (result.output === "success") {
                        alert('success')
                    }
                }
                else {
                    alert('failed')
                }

            };
            { /*checkInTeams ? microsoftTeams.tasks.startTask(taskInfo, submitHandler) : <TaskModal /> */}
            microsoftTeams.tasks.startTask(taskInfo, submitHandler)
            
        }
    }

    //Handles escape function
    const escFunction = (e) => {
        if (e.keyCode === 27 || (e.key === "Escape")) {
            microsoftTeams.tasks.submitTask();
        }
    }
    //Task Module end
    const inputItems = [
        {
            header: 'Bruce Wayne',
            image: 'public/images/avatar/small/matt.jpg',
            content: 'Software Engineer',
            firstName: 'Bruce'
        },
        {
            header: 'Natasha Romanoff',
            image: 'public/images/avatar/small/jenny.jpg',
            content: 'UX Designer 2',
            firstName: 'Natasha'

        },
        {
            header: 'Steven Strange',
            image: 'public/images/avatar/small/joe.jpg',
            content: 'Principal Software Engineering Manager',
            firstName: 'Natasha'
        },
        {
            header: 'Alfred Pennyworth',
            image: 'public/images/avatar/small/justen.jpg',
            content: 'Technology Consultant',
            firstName: 'Natasha'
        },
        {
            header: `Scarlett O'Hara`,
            image: 'public/images/avatar/small/laura.jpg',
            content: 'Software Engineer 2',
            firstName: 'Natasha'
        },
        {
            header: 'Imperator Furiosa',
            image: 'public/images/avatar/small/veronika.jpg',
            content: 'Boss',
            firstName: 'Natasha'
        },
        {
            header: 'Bruce Banner',
            image: 'public/images/avatar/small/chris.jpg',
            content: 'Senior Computer Scientist',
            firstName: 'Natasha'
        },
        {
            header: 'Peter Parker',
            image: 'public/images/avatar/small/daniel.jpg',
            content: 'Partner Software Engineer',
            firstName: 'Natasha'
        },
        {
            header: 'Selina Kyle',
            image: 'public/images/avatar/small/ade.jpg',
            content: 'Graphic Designer',
            firstName: 'Natasha'
        },
    ]

    const persons = [
        'Bruce Wayne',
        'Natasha Romanoff',
        'Steven Strange',
        'Alfred Pennyworth',
        `Scarlett O'Hara`,
        'Imperator Furiosa',
        'Bruce Banner',
        'Peter Parker',
        'Selina Kyle',
        'Dheeraj Kasivi',
        'Vandana Srivatsava',
        'Kishore Kumar AVN',
        'Lalitha Aadukuri',
        'Amit Mann',
        'Sita Prasad'
    ]

    const timeZones = [
        '+5:00',
        '+5:30',
        '+5:45',
        '-5:00',
        '-4:00',
        '-4:30',
        '-4:45'
    ]
    //const getA11ySelectionMessage = {
    //    onAdd: item => alert(`${item.header} has been selected.`),
    //    onRemove: item => alert(`${item.header} has been removed.`)
    //}
    const [messagePersonalize, setmessagePersonalize] = React.useState({ value: null });
    const peopleClick = e => {
        console.log("clicked");
    };
    const getA11ySelectionMessage = {
        onAdd: item => addMail(item),
        onRemove: item => removeMail(item),
        onHighlightedIndexChange: item => alert(item.header)
    }
    const addMail = (item) => {
        setSelectedPerson(mails.length)
        setMails([...mails, {
            id: mails.length,
            person: item.header,
            subject: 'personalize subject || ' + item.header,
            body: 'Hi ' + item.header,
            firstName: 'sample'
        }])
    }
    const removeMail = (item) => {
        alert(item.header);
    }
    const updateMail = (item) => {
        alert('update')
        setMails(
            mails.map(mail =>
                mail.id === item.id
                    ? { ...mail, isSelected: true }
                    : mail
            ))
    }
    const _onChange = () => {
        setIsPreview(current => !current);
    }
    const getCurrentSubject = () => {
        if (mails.length > 0)
            return mails.filter(mail => mail.id == selectedPerson)[0].subject
        else
            return 'default subject'
    }
    const getCurrentMailBody = () => {
        if (mails.length > 0)
            return mails.filter(mail => mail.id == selectedPerson)[0].body
        else
            return 'default body'
    }

    
    const ActionButtons = () => (
        <div>
            <Flex gap="gap.small">
                <FlexItem>
                    <SplitButton
                        menu={[
                            {
                                key: 'delay-send',
                                content: 'Delay Send',
                            }
                        ]}
                        button={{
                            content: 'Preview & Send',
                            'aria-roledescription': 'splitbutton',
                            'aria-describedby': 'instruction-message-primary-button',
                        }}
                        primary
                        toggleButton={{
                            'aria-label': 'more options',
                        }}
                        onMainButtonClick={() => alert('button was clicked')}
                    />
                   
                </FlexItem>
                <Button content="Save as Template" />
                <Button content="Discard" />
            </Flex>
            <Divider />
        </div>
    )
    return (
        <div>
            <Flex grow>
                <Flex.Item push>
                    <Checkbox label="Preview Mail" toggle onChange={_onChange} hidden/>
                </Flex.Item>
            </Flex>
            <Divider />

            <Grid columns="0.1fr 4fr" grow>
                <Segment>
                    <UserBlurIcon size="large" outline />
                </Segment>
                <Segment>
                    {isPreview ? <Input placeholder="On behalf of" fluid disabled/> : <Input placeholder="On behalf of" fluid />}
                </Segment>
                <Segment>
                    <ParticipantAddIcon size="large" outline />
                </Segment>
                <Segment>
                    <Flex gap="gap.smaller">
                        <FlexItem grow>
                            {isPreview ? <Dropdown
                                multiple
                                search
                                fluid
                                items={inputItems}
                                placeholder="Add recipients"
                                getA11ySelectionMessage={getA11ySelectionMessage}
                                noResultsMessage="We couldn't find any matches."
                                onClick={peopleClick}
                                disabled /> : <Dropdown
                                    multiple
                                    search
                                    fluid
                                    items={inputItems}
                                    placeholder="Add recipients"
                                    getA11ySelectionMessage={getA11ySelectionMessage}
                                    noResultsMessage="We couldn't find any matches."
                                    onClick={peopleClick}
                                     /> }
                        </FlexItem>

                        {!isPreview ? <Button content="Dynamic Audience" loader="Opening Dynamic Audience" secondary /> :
                            <Button content="Dynamic Audience" loader="Opening Dynamic Audience" secondary hidden />}
                    </Flex>

                </Segment>
                <Segment>
                    <EditIcon size="large" outline />
                </Segment>
                <Segment>
                    <Flex gap="gap.smaller">
                        <FlexItem grow>
                            {isPreview ? <MailSubject mailSubject={getCurrentSubject()} /> :
                                <MailSubject mailSubject={getCurrentSubject()} disabled />}
                        </FlexItem>
                        <FlexItem push>
                            <Dropdown items={['High Importance', 'Low Importance']} fluid />
                        </FlexItem>
                        {!inTeams ? <Dialog
                            open={open}
                            onOpen={() => setOpen(true)}
                            content={<Personalize />}
                            header="Personalize"
                            headerAction={{
                                icon: <CloseIcon />,
                                title: 'Close',
                                onClick: () => setOpen(false),
                            }}
                            onCancel={() => setOpen(false)}
                            
                            trigger={<Button aria-label={'Personalize'} content={'Personalize'} onClick={() => onOpenTaskModule()} className="Personalize" primary />}
                        /> : null
                        }
                        
                    </Flex>
                </Segment>
                <Segment>
                    <ChatIcon size="large" outline />
                </Segment>
                <Segment>
                    <Editor messageBody={getCurrentMailBody()} isEditable={!isPreview} />
                </Segment>
                <Segment>

                </Segment>
                <Segment>
                    <Attachment icon={<WordColorIcon />} header="MeetingNotes.docx" />
                    <Attachment icon={<ExcelColorIcon />} header="Budget.xlsx" />
                    <Attachment icon={<PowerPointColorIcon />} header="Presentation.pptx" />
                    <Attachment
                        header="Photo.jpg"
                        actionable
                        action={{
                            icon: <CloseIcon />,
                            title: 'Close',
                        }}
                        progress={33}
                    />
                </Segment>
                <Segment>
                </Segment>
                {isPreview ? null : <ActionButtons />}
                <Segment>
                </Segment>
            </Grid>
        </div>
    );
}

export default ComposeEmail;
