﻿import React, { useState} from 'react'
import { List, Image, ButtonGroup, Divider } from '@fluentui/react-northstar'
import { ThumbtackIcon, MoreIcon } from '@fluentui/react-icons-northstar'
import TemplateHeader from './TemplateHeader';
import LastAccessed from './LastAccessed';
import TemplateSubject from './TemplateSubject';
import MailImportance from './MailImportance';



//class ListExample extends React.Component {
const ListExample = (props) => {
    //state = {
    //    selectedIndex: -1,
    //}
    const [state, setState] = React.useState({ selectedIndex: props.selectedTemplateIndex })
    //render() {
    return (
        <div style={{ width: '19rem'}} >
                <List
                    selectable
                    selectedIndex={state.selectedIndex}
                    onSelectedIndexChange={(e, newProps) => {
                        //alert(
                        //    `Showing preview for "${newProps.selectedIndex}"`,
                        //)
                        setState({
                            selectedIndex: newProps.selectedIndex,
                        })
                        props.changeTemplatePreviewData(newProps.selectedIndex)
                    }}
                    items={props.templates}
                    truncateHeader={true}
                    truncateContent={true}
                />
            </div>

        )
    //}
}

export default ListExample

//BACKUP 1
//return (
//    <div style={{ width: '20rem' }} >
//        <List
//            selectable
//            selectedIndex={this.state.selectedIndex}
//            onSelectedIndexChange={(e, newProps) => {
//                alert(
//                    `List is requested to change its selectedIndex state to "${newProps.selectedIndex}"`,
//                )
//                this.setState({
//                    selectedIndex: newProps.selectedIndex,
//                })
//            }}
//            items={this.props.templates}
//            truncateHeader={true}
//            truncateContent={true}
//        />
//        <Divider vertical />
//    </div>

//)

//BACKUP 0
//actions = (
//    <ButtonGroup
//        buttons={[
//            {
//                icon: <ThumbtackIcon />,
//                iconOnly: true,
//                text: true,
//                title: 'pin',
//                key: 'pin',
//            },
//            {
//                icon: <MoreIcon />,
//                iconOnly: true,
//                text: true,
//                title: 'more',
//                key: 'more',
//            },
//        ]}
//    />
//)
//items = [
//    {
//        key: 'irving',
//        header: <TemplateHeader value={"Template Name 1"} />,
//        headerMedia: <LastAccessed value={"09:20 AM"} />,
//        content: <TemplateSubject value={'Subject 1 - Test email 1 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
//        contentMedia: <MailImportance value={'high'} />,
//        endMedia: this.actions,
//    },
//    {
//        key: 'irving',
//        header: <TemplateHeader value={"Template Name 2"} />,
//        headerMedia: <LastAccessed value={"11:10 PM"} />,
//        content: <TemplateSubject value={'Subject 2 - Test email 2 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
//        contentMedia: '',
//        endMedia: this.actions,
//    },
//    {
//        key: 'irving',
//        header: <TemplateHeader value={"Template Name 3"} />,
//        headerMedia: <LastAccessed value={"12:00 AM"} />,
//        content: <TemplateSubject value={'Subject 3 - Test email 3 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
//        contentMedia: <MailImportance value={'high'} />,
//        endMedia: this.actions,
//    },
//    {
//        key: 'irving',
//        header: <TemplateHeader value={"Template Name 4"} />,
//        headerMedia: <LastAccessed value={"4/12"} />,
//        content: <TemplateSubject value={'Subject 1 - Test email 1 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
//        contentMedia: <MailImportance value={'high'} />,
//        endMedia: this.actions,
//    },
//    {
//        key: 'irving',
//        header: <TemplateHeader value={"Template Name 5 truncate check lengthy text"} />,
//        headerMedia: <LastAccessed value={"2/12"} />,
//        content: <TemplateSubject value={'Subject 1 - Test email 1 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
//        contentMedia: '',
//        endMedia: this.actions,
//    },
//    {
//        key: 'irving',
//        header: <TemplateHeader value={"Template Name 6"} />,
//        headerMedia: <LastAccessed value={"30/11"} />,
//        content: <TemplateSubject value={'Subject 1 - Test email 1 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
//        contentMedia: '',
//        endMedia: this.actions,
//    },
//    {
//        key: 'irving',
//        header: <TemplateHeader value={"Template Name 7"} />,
//        headerMedia: <LastAccessed value={"24/11"} />,
//        content: <TemplateSubject value={'Subject 1 - Test email 1 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
//        contentMedia: <MailImportance value={'high'} />,
//        endMedia: this.actions,
//    }

//]